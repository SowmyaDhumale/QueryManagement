package com.cg.project.service;

import java.util.List;

import com.cg.project.beans.QueryMaster;
import com.cg.project.exception.QueryException;

public interface IQueryService {
	public QueryMaster getQuery(int id) throws QueryException;

}
