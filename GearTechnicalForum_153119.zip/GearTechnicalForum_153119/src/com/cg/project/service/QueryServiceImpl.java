package com.cg.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.project.beans.QueryMaster;
import com.cg.project.exception.QueryException;
import com.cg.project.repo.IQueryDAO;



@Component
public class QueryServiceImpl implements IQueryService {
	
	@Autowired
	private IQueryDAO repo;

	@Override
	public QueryMaster getQuery(int id) throws QueryException{
		QueryMaster queryMaster =  repo.findOne(id);
		if(queryMaster == null)
			throw new QueryException();
		else 
			return queryMaster;
		
		
		
	}

}
