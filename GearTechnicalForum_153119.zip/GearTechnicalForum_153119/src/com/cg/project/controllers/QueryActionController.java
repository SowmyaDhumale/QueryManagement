package com.cg.project.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.project.beans.QueryMaster;
import com.cg.project.exception.QueryException;
import com.cg.project.repo.IQueryDAO;
import com.cg.project.service.IQueryService;


@Controller
public class QueryActionController {
@Autowired
private IQueryService service;

@Autowired
private IQueryDAO repo;

@RequestMapping(value="/viewDetails")
public ModelAndView ViewDetails(@RequestParam("query_id") int id) throws QueryException   {
		
		if(id ==1||id==2||id==3||id==4) {
			QueryMaster queryMaster = service.getQuery(id);
			return new ModelAndView("detailsPage", "queryMaster",queryMaster);
		}else {
			return new ModelAndView("unsuccesspage", "id", id);
		}
	

}



@RequestMapping(value="/updateQuery")
public ModelAndView updateQuery(@ModelAttribute("queryMaster") QueryMaster queryMaster) {
		repo.save(queryMaster);
	return new ModelAndView("successPage", "queryMaster",queryMaster);
}

}
